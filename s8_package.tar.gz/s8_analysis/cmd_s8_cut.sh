for i in {10..51}
do
echo $i
cp s8.* run_$i/
cd run_$i
root -l s8.C <<EOF
s8 t
t.Loop()
EOF
cd ..
done
