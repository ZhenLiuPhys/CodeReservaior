for i in {51..60}; do
sed 's/xxx/'$i'/g' param_card_s8.dat > param_card_s8.temp
sed 's/yyy/'$i'/g' param_card_s8.temp > sgg/Cards/param_card.dat
./mg5 <<EOF
launch sgg -m
8
1
0
EOF
done
