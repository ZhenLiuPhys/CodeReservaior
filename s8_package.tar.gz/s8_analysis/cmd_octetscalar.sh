j=9
for i in $(cat widthtable.dat); do
echo $i
j=`expr $j + 1`
echo $j
sed 's/xxx/'$j'/g' param_card_s8.dat > param_card_s8.temp
sed 's/yyy/'$i'/g' param_card_s8.temp > ggs8gg/Cards/param_card.dat
sed 's/xxx/'$j'/g' run_card.dat > ggs8gg/Cards/run_card.dat
./mg5 <<EOF
launch ggs8gg -m
8
1
0
EOF
done
